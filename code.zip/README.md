# ContextualMAB.github.io
This is the experiment about Contextual-MAB. python:  
Hyperparameters: Explained in the appendix of paper.
The algorithm will ask you to give a T value, since sometime offline part will be too good that gap is 0. So if offline_gap is 0, you can halt the algorithm when asking T.
If continue, choose T 8000 for reference.(other value is ok, just we choose 8000.)
